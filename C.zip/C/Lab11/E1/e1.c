#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "datetime.h"
#include "titoli.h"
#include "quotazioni.h"

#define N_SCELTE 8
#define DBG 0

enum { falso, vero };
typedef int bool;

void leggiFile(char *fn, LISTtitoli LISTtitoli) {
  char cod[LEN], data[DATELEN], ora[TIMELEN];
  int quote = 0, i, qta;
  float valore;
  Titolo t;
  FILE *fp = fopen(fn, "r");
  if (fp == NULL)
    return;

  while(fscanf(fp, "%s %d\n", cod, &quote) == 2) {
	t =	LISTtitoliSearch(LISTtitoli, cod);
    if (t == NULL) {
      t = TITOLOnew(cod);
      LISTtitoliInsert(LISTtitoli, t);
    }

	for (i=0; i<quote; i++) {
      fscanf(fp, "%s %s %f %d\n", data, ora, &valore, &qta);
      TITOLOinsertTransazione(t, DATAload(data), ORAload(ora), valore, qta);
    }
  }

  fclose(fp);
  return;
}

void stampaMenu(char *scelte[], int *selezione){
  int i=0;
  printf("\nMENU'\n");
  for (i=0; i<N_SCELTE; i++)
    printf("%2d > %s\n",i,scelte[i]);
  scanf(" %d",selezione);
}

int main(int argc, char **argv) {
  char *scelte[] = {
		"Uscita",
        "Leggi file",
		"Stampa titoli",
		"Stampa titolo",
		"Stampa quotazione",
		"Stampa quotazione MIN/MAX assoluti",
		"Stampa quotazione MIN/MAX intervallo",
		"Bilanciamento"
	};

  LISTtitoli titoli = LISTtitoliInit();
  Titolo t;
  Quotazione q;
  float f1, f2;
  char strTmp[100], strTmp1[100];
  int selezione = 0;
  bool fineProgramma = falso;

  /* A titolo di prova, precarica alcuni file... */
  leggiFile("F1.txt", titoli);
  leggiFile("F2.txt", titoli);
  leggiFile("F3.txt", titoli);

  do {
		stampaMenu(scelte, &selezione);
		switch(selezione){

			case 0: {
				fineProgramma = vero;
		  } break;

			case 1: {
				printf("Inserire nome file: ");
				scanf("%s", strTmp);
                leggiFile(strTmp, titoli);
			} break;

			case 2: {
				LISTtitoliStore(titoli, stdout);
			} break;

			case 3: {
                printf("Inserire codice titolo: ");
				scanf("%s", strTmp);
				t = LISTtitoliSearch(titoli, strTmp);
				if (t != NULL)
                  TITOLOstore(stdout, t);
			} break;

			case 4: {
                printf("Inserire codice titolo: ");
				scanf("%s", strTmp);
				t = LISTtitoliSearch(titoli, strTmp);
				if (t != NULL) {
                  printf("Inserire data: ");
                  scanf("%s", strTmp);
                  q = TITOLOgetQuotazione(t, DATAload(strTmp));
                  QUOTAZIONEstore(stdout, q);
                }
			} break;

			case 5: {
                printf("Inserire codice titolo: ");
				scanf("%s", strTmp);
				t = LISTtitoliSearch(titoli, strTmp);
				if (t != NULL)
                  printf("MIN = %f || MAX = %f\n", TITOLOminAssoluto(t), TITOLOmaxAssoluto(t));
			} break;

      case 6: {
                printf("Inserire codice titolo: ");
				scanf("%s", strTmp);
				t = LISTtitoliSearch(titoli, strTmp);
				if (t != NULL) {
                  printf("Inserire data 1: ");
                  scanf("%s", strTmp);
                  printf("Inserire data 2: ");
                  scanf("%s", strTmp1);
                  TITOLOminmaxRange(t, DATAload(strTmp), DATAload(strTmp1), &f1, &f2);
                  printf("MIN = %f || MAX = %f\n", f1, f2);
				}
			} break;

      case 7: {
                printf("Inserire codice titolo: ");
				scanf("%s", strTmp);
				t = LISTtitoliSearch(titoli, strTmp);
				if (t != NULL)
                  TITOLOtreeBalance(t);
			} break;

			default:{
				printf("Scelta non valida\n");
			} break;
		}
	} while(!fineProgramma);

  return 0;
}
